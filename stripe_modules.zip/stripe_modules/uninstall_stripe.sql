-- Striope payment module delete statement
DROP TABLE IF EXISTS `stripe`;