<?php if(MODULE_PAYMENT_STRIPE_STATUS === 'True' && $stripe_select == 'True' ) {?>
    <link rel="stylesheet" href="checkout_confirmation.css" />
     <script src="https://js.stripe.com/v3/"></script>
    <script src="includes/checkout.js" defer></script>
 <?php } ?>


