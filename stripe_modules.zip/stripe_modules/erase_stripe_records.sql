-- Striope payment module erase all recodes  statement
TRUNCATE ` stripe `;